# Instabot

Instagram promotion and SMM scripts.
Forever free. Written in Python.

---
### [Read the Docs](https://instagrambot.github.io/docs/) | [Contribute](https://github.com/instagrambot/docs/blob/master/CONTRIBUTING.md)
---

[![Telegram Chat](https://img.shields.io/badge/chat%20on-Telegram-blue.svg)](https://t.me/instabotproject)
![Python 2.7, 3.5, 3.6](https://img.shields.io/badge/python-2.7%2C%203.5%2C%203.6-blue.svg)
[![PyPI version](https://badge.fury.io/py/instabot.svg)](https://badge.fury.io/py/instabot)
[![Build Status](https://travis-ci.org/instagrambot/instabot.svg?branch=master)](https://travis-ci.org/instagrambot/instabot)
[![codecov](https://codecov.io/gh/instagrambot/instabot/branch/master/graph/badge.svg)](https://codecov.io/gh/instagrambot/instabot)
<span class="badge-bitcoin"><a href="https://github.com/instagrambot/instabot/blob/master/.github/DONATE_BITCOIN.md" title="Donate once-off to this project using Bitcoin"><img src="https://img.shields.io/badge/bitcoin-donate-yellow.svg" alt="Bitcoin donate button" /></a></span>

### Installation
Install `instabot` with:
```
pip install -U instabot
```
#### or see [this](https://instagrambot.github.io/docs/en/#installation) for more details.



![Instabot is better than other open-source bots!](https://github.com/instagrambot/docs/blob/master/img/instabot_3_bots.png "Instabot is better than other open-source bots!")
